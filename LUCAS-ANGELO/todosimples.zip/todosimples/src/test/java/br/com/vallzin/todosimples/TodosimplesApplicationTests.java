package br.com.vallzin.todosimples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodosimplesApplicationTests {

	@Test
	void contextLoads() {
	}

}

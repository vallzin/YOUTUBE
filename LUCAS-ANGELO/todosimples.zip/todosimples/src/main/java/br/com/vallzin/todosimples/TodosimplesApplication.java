package br.com.vallzin.todosimples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodosimplesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodosimplesApplication.class, args);
	}

}
